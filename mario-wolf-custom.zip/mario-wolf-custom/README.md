# Mario Wolf - protótipo
Jogo de plataforma HTML5 Canvas usando os recortes da spritesheet enviada.

Controles: setas/A-D mover, Shift correr, Espaço/Z/↑ pular, ↓/S agachar, J atacar, R reiniciar.

Publique todos os arquivos em um repositório GitHub e ative Settings > Pages > Deploy from a branch > main > /(root).
